Dados locais e snapshots podem ser adicionados aqui futuramente. A versão principal tenta ler o TSE diretamente pelo navegador.
