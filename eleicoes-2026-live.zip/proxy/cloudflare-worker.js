/* Optional CORS proxy for deployments that cannot fetch resultados.tse.jus.br directly.
   Deploy as a Cloudflare Worker and open the site with:
   ?tseProxy=https://SEU-WORKER.workers.dev
*/
export default {
  async fetch(request) {
    const u = new URL(request.url);
    const target = u.searchParams.get('url');
    const allowed = target && target.startsWith('https://resultados.tse.jus.br/oficial/');
    if (!allowed) return new Response('URL não permitida', { status: 400 });
    try {
      const resp = await fetch(target, { headers: { 'Accept': 'application/json' }, cf: { cacheTtl: 0, cacheEverything: false } });
      const body = await resp.arrayBuffer();
      return new Response(body, { status: resp.status, headers: { 'content-type': 'application/json; charset=utf-8', 'access-control-allow-origin': '*' } });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 502, headers: { 'content-type': 'application/json', 'access-control-allow-origin': '*' } });
    }
  }
};
