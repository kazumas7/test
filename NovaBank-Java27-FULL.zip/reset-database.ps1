Set-Location $PSScriptRoot
Remove-Item .\data\novabank.mv.db -ErrorAction SilentlyContinue
Remove-Item .\data\novabank.trace.db -ErrorAction SilentlyContinue
Write-Host "Banco apagado. Abra a aplicacao novamente para recriar as duas contas com R$ 1.000.000,00 cada."
