$ErrorActionPreference = 'Stop'
Write-Host "Verificando Nova Bank..." -ForegroundColor Cyan
if (-not (Test-Path .\pom.xml)) { throw "pom.xml ausente" }
if (-not (Test-Path .\src\main\java\com\novabank\NovaBankApplication.java)) { throw "Classe principal ausente" }
$java = Get-Command java -ErrorAction SilentlyContinue
if ($java) { java -version }
Write-Host "Estrutura OK. No IntelliJ: abra a pasta, sincronize o pom.xml e execute NovaBankApplication." -ForegroundColor Green
