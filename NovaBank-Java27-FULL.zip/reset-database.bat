@echo off
setlocal
cd /d "%~dp0"
if exist "data\novabank.mv.db" del /q "data\novabank.mv.db"
if exist "data\novabank.trace.db" del /q "data\novabank.trace.db"
echo Banco apagado. Abra a aplicacao novamente para recriar as duas contas com R$ 1.000.000,00 cada.
pause
