NOVA BANK — PRIMEIRA EXECUÇÃO NO INTELLIJ

1) Extraia o ZIP.
2) Abra a pasta que contém pom.xml.
3) File > Open > selecione essa pasta.
4) Confirme JDK 27 em Project Structure > Project SDK.
5) Aguarde a sincronização do Maven terminar.
6) Abra src/main/java/com/novabank/NovaBankApplication.java.
7) Clique no triângulo verde ao lado do main().

CONFIGURAÇÃO PRONTA

.run/NovaBankApplication.run.xml
Tipo: Application
Main class: com.novabank.NovaBankApplication
Module: nova-bank
Before launch: Make

URL DO SITE

http://localhost:8080

CONTAS

Ana:
ana@novabank.local
12345678
10000001
ana@pix.novabank
R$ 1.000.000,00

Bruno:
bruno@novabank.local
12345678
10000002
bruno@pix.novabank
R$ 1.000.000,00

BANCO

H2 persistente em:
data/novabank.mv.db

RESET

Pare a aplicação e execute reset-database.bat para começar novamente com R$ 1.000.000,00 em cada conta.
