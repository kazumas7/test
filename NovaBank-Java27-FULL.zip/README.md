# Nova Bank — Java 27 + IntelliJ

Sistema bancário de demonstração, autocontido e voltado para estudo.

> **Aviso:** este projeto não é um banco real e o Pix aqui é uma **simulação interna** entre contas do próprio projeto. Ele não se conecta ao SPI, não movimenta dinheiro real e não usa um provedor de Pix.

## Stack

- Java 27
- Spring Boot 4.2.0-M2 (linha que declara compatibilidade com Java 27)
- Spring MVC / REST
- Thymeleaf
- Spring Security + BCrypt
- Spring Data JPA / Hibernate
- H2 em arquivo
- Actuator / health
- JavaScript moderno (Fetch API)
- HTML5 + CSS responsivo

## O que funciona

1. Cadastro de usuário
2. Login e logout
3. Conta bancária automática
4. Chave Pix automática
5. Saldo persistente
6. Depósito
7. Saque com validação de saldo
8. Transferência por número de conta
9. Pix por chave Pix (simulado e persistente)
10. Extrato com referências das operações
11. Consulta de destinatário antes de transferir
12. Dashboard com entradas e saídas
13. Banco local persistente em `data/novabank.mv.db`
14. H2 Console em `/h2-console`
15. Health check em `/actuator/health`
16. API REST usada pelo JavaScript do site
17. Formulários HTML continuam funcionando como fallback mesmo sem JavaScript
18. Testes automatizados no diretório `src/test`

## Contas prontas

### Ana Silva

- E-mail: `ana@novabank.local`
- Senha: `12345678`
- Conta: `10000001`
- Pix: `ana@pix.novabank`
- Saldo inicial: **R$ 1.000.000,00**

### Bruno Lima

- E-mail: `bruno@novabank.local`
- Senha: `12345678`
- Conta: `10000002`
- Pix: `bruno@pix.novabank`
- Saldo inicial: **R$ 1.000.000,00**

## Teste rápido

1. Entre como Ana.
2. Abra **Transferir** e mande `100` para a conta `10000002`.
3. O saldo da Ana cai e o saldo do Bruno sobe.
4. Faça logout.
5. Entre como Bruno e confira o extrato.
6. Volte para Ana e use **Pix** com a chave `bruno@pix.novabank` para enviar `50`.
7. Entre como Bruno novamente e confira o Pix recebido.
8. Feche a aplicação e abra novamente: os valores continuam salvos.

## Abrir no IntelliJ IDEA

1. Extraia o ZIP.
2. Abra **a pasta raiz que contém o `pom.xml`**.
3. Confirme o **Project SDK = JDK 27**.
4. Espere o IntelliJ sincronizar o Maven.
5. Abra `src/main/java/com/novabank/NovaBankApplication.java`.
6. Execute o `main()` pelo botão verde.

Também existe uma configuração compartilhada em:

`.run/NovaBankApplication.run.xml`

Ela é do tipo **Application**, aponta para `com.novabank.NovaBankApplication` e executa **Make** antes de rodar.

## Muito importante no IntelliJ

Não abra apenas `src`, `src/main/java` ou um arquivo isolado. Abra a **pasta do projeto**.

Se a IDE mostrar uma configuração antiga apontando para um módulo inexistente, apague essa configuração e use a configuração `NovaBankApplication` que vem dentro da pasta `.run`.

## Banco persistente

Os dados ficam no próprio projeto:

`data/novabank.mv.db`

Não é preciso instalar PostgreSQL, Docker ou Tomcat separado.

### Reset das contas de demonstração

Pare o programa e execute:

`reset-database.bat`

Depois inicie o projeto novamente. As contas demo serão recriadas com R$ 1.000.000,00 cada.

## H2 Console

Com a aplicação rodando:

`http://localhost:8080/h2-console`

JDBC URL:

`jdbc:h2:file:./data/novabank`

User: `sa`

Password: deixe vazio.

## API REST

Com login ativo:

- `GET /api/dashboard`
- `POST /api/deposit`
- `POST /api/withdraw`
- `POST /api/transfer`
- `POST /api/pix`
- `GET /api/lookup/account/{accountNumber}`
- `GET /api/lookup/pix?key=...`

Exemplo de depósito:

```json
{
  "amount": 250.00
}
```

Exemplo de transferência:

```json
{
  "targetAccount": "10000002",
  "amount": 100.00
}
```

Exemplo de Pix simulado:

```json
{
  "pixKey": "bruno@pix.novabank",
  "amount": 50.00
}
```

## Arquitetura

```text
Browser
  ↓
Thymeleaf + CSS + JavaScript
  ↓
Spring MVC / REST Controllers
  ↓
BankingService / regras de negócio
  ↓
Spring Data JPA
  ↓
Hibernate
  ↓
H2 file database
  ↓
data/novabank.mv.db
```

Transferências e Pix alteram as duas contas na mesma transação do banco e registram duas linhas no extrato, uma para saída e outra para entrada.

## Build Maven

O IntelliJ pode importar o projeto pelo `pom.xml` e executar a classe principal diretamente. Spring Boot documenta a execução de uma aplicação a partir da IDE como uma aplicação Java normal.

Para linha de comando, é necessário ter Maven instalado:

```text
mvn spring-boot:run
```

ou:

```text
mvn test
```

## Verificação local

O arquivo `verify-project.ps1` confere a estrutura mínima do projeto. O build completo com Java 27 precisa ser feito na sua máquina porque este pacote não inclui o JDK.
