(() => {
    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

    const toast = (message, isError = false) => {
        const el = $('#toast');
        if (!el) return;
        el.textContent = message;
        el.classList.toggle('error', isError);
        el.classList.add('show');
        clearTimeout(window.__novaToastTimer);
        window.__novaToastTimer = setTimeout(() => el.classList.remove('show'), 3400);
    };

    const openModal = id => {
        const modal = document.getElementById(id);
        if (!modal) return;
        modal.setAttribute('aria-hidden', 'false');
        const focusable = $('input, button', modal);
        setTimeout(() => focusable?.focus(), 80);
    };

    const closeModal = modal => {
        if (modal) modal.setAttribute('aria-hidden', 'true');
    };

    $$('[data-modal]').forEach(btn => btn.addEventListener('click', () => openModal(btn.dataset.modal)));
    $$('[data-close]').forEach(btn => btn.addEventListener('click', () => closeModal(btn.closest('.modal'))));
    $$('.modal').forEach(modal => modal.addEventListener('click', e => {
        if (e.target === modal) closeModal(modal);
    }));
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') closeModal($('.modal[aria-hidden="false"]'));
    });

    $$('[data-copy-target]').forEach(button => button.addEventListener('click', async () => {
        const target = document.getElementById(button.dataset.copyTarget);
        if (!target) return;
        try {
            await navigator.clipboard.writeText(target.textContent.trim());
            toast('Copiado para a área de transferência.');
        } catch (_) {
            toast('Não foi possível copiar automaticamente.', true);
        }
    }));

    $$('[data-amount-target]').forEach(button => button.addEventListener('click', () => {
        const target = document.getElementById(button.dataset.amountTarget);
        if (target) target.value = button.dataset.amount;
    }));

    const toggle = $('#toggleBalance');
    const balance = $('#balanceValue');
    if (toggle && balance) {
        let hidden = false;
        toggle.addEventListener('click', () => {
            hidden = !hidden;
            balance.classList.toggle('masked', hidden);
            balance.querySelector('span').textContent = hidden ? '••••••' : balance.dataset.original;
            toggle.textContent = hidden ? '◌' : '◉';
            toggle.setAttribute('aria-label', hidden ? 'Mostrar saldo' : 'Ocultar saldo');
        });
        const span = balance.querySelector('span');
        if (span) balance.dataset.original = span.textContent;
    }

    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || document.querySelector('input[name="_csrf"]')?.value || '';
    const requestJson = async (url, payload) => {
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrf
            },
            body: JSON.stringify(payload)
        });
        let data = null;
        try { data = await res.json(); } catch (_) { /* empty */ }
        if (!res.ok) throw new Error(data?.message || `Erro ${res.status}`);
        return data;
    };

    $$('.operation-form').forEach(form => form.addEventListener('submit', async e => {
        if (!form.dataset.api) return;
        e.preventDefault();
        const button = $('button[type="submit"]', form);
        const formData = new FormData(form);
        const payload = {};
        for (const [key, value] of formData.entries()) {
            if (key === '_csrf') continue;
            payload[key] = key === 'amount' ? Number(value) : value.trim();
        }
        if (!payload.amount || payload.amount <= 0) {
            toast('Digite um valor válido.', true);
            return;
        }
        form.classList.add('loading');
        if (button) button.disabled = true;
        try {
            const result = await requestJson(form.dataset.api, payload);
            toast(`${result.message} Ref.: ${result.reference}`);
            setTimeout(() => window.location.reload(), 650);
        } catch (err) {
            toast(err.message || 'Não foi possível concluir a operação.', true);
        } finally {
            form.classList.remove('loading');
            if (button) button.disabled = false;
        }
    }));

    const lookup = async (url, target) => {
        try {
            target.textContent = 'Consultando destinatário…';
            target.className = 'recipient-preview';
            const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
            const data = await res.json();
            if (!res.ok || !data.found) throw new Error(data.message || 'Destinatário não encontrado.');
            target.textContent = `✓ Destinatário: ${data.ownerName}`;
            target.className = 'recipient-preview good';
        } catch (err) {
            target.textContent = err.message;
            target.className = 'recipient-preview bad';
        }
    };

    const accountInput = $('#targetAccount');
    const accountPreview = $('#accountPreview');
    accountInput?.addEventListener('blur', () => {
        const value = accountInput.value.trim();
        if (value.length === 8) lookup(`/api/lookup/account/${encodeURIComponent(value)}`, accountPreview);
    });

    const pixInput = $('#pixKeyInput');
    const pixPreview = $('#pixPreview');
    pixInput?.addEventListener('blur', () => {
        const value = pixInput.value.trim();
        if (value) lookup(`/api/lookup/pix?key=${encodeURIComponent(value)}`, pixPreview);
    });

    // Preenche o login sem senha hard-coded no backend: os botões só populam a tela.
    $$('.demo-fill').forEach(button => button.addEventListener('click', () => {
        const email = $('#username');
        const password = $('#password');
        if (!email || !password) return;
        email.value = button.dataset.email;
        password.value = button.dataset.password;
        email.focus();
        toast('Dados da conta de teste preenchidos.');
    }));

    // Fecha os alertas renderizados pelo servidor após alguns segundos.
    setTimeout(() => $$('.alert').forEach(el => {
        el.style.transition = 'opacity .3s, transform .3s';
        el.style.opacity = '0';
        el.style.transform = 'translateY(-5px)';
        setTimeout(() => el.remove(), 320);
    }), 5200);
})();
