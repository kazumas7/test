package com.novabank.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "bank_transactions", indexes = {
        @Index(name = "idx_transactions_account_date", columnList = "account_id, created_at"),
        @Index(name = "idx_transactions_reference", columnList = "reference_code", unique = true)
})
public class BankTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "account_id", nullable = false)
    private BankAccount account;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TransactionType type;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(nullable = false, length = 180)
    private String description;

    @Column(length = 80)
    private String counterparty;

    @Column(nullable = false, length = 60, unique = true)
    private String referenceCode;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @PrePersist
    void onCreate() {
        if (createdAt == null) createdAt = LocalDateTime.now();
    }

    public UUID getId() { return id; }
    public BankAccount getAccount() { return account; }
    public TransactionType getType() { return type; }
    public BigDecimal getAmount() { return amount; }
    public String getDescription() { return description; }
    public String getCounterparty() { return counterparty; }
    public String getReferenceCode() { return referenceCode; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public void setAccount(BankAccount account) { this.account = account; }
    public void setType(TransactionType type) { this.type = type; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public void setDescription(String description) { this.description = description; }
    public void setCounterparty(String counterparty) { this.counterparty = counterparty; }
    public void setReferenceCode(String referenceCode) { this.referenceCode = referenceCode; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
