package com.novabank.entity;

public enum AccountStatus {
    ACTIVE,
    BLOCKED
}
