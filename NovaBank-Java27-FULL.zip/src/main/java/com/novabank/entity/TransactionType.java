package com.novabank.entity;

public enum TransactionType {
    DEPOSIT,
    WITHDRAWAL,
    TRANSFER_IN,
    TRANSFER_OUT,
    PIX_IN,
    PIX_OUT
}
