package com.novabank.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(name = "bank_accounts", indexes = {
        @Index(name = "idx_bank_accounts_number", columnList = "account_number", unique = true),
        @Index(name = "idx_bank_accounts_pix_key", columnList = "pix_key", unique = true),
        @Index(name = "idx_bank_accounts_owner", columnList = "owner_id", unique = true)
})
public class BankAccount {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "account_number", nullable = false, unique = true, length = 8)
    private String accountNumber;

    @Column(name = "pix_key", nullable = true, unique = true, length = 80)
    private String pixKey;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal balance = BigDecimal.ZERO.setScale(2);

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AccountStatus status = AccountStatus.ACTIVE;

    @Version
    private Long version;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "owner_id", nullable = false, unique = true)
    private UserAccount owner;

    public UUID getId() { return id; }
    public String getAccountNumber() { return accountNumber; }
    public String getPixKey() { return pixKey; }
    public BigDecimal getBalance() { return balance; }
    public AccountStatus getStatus() { return status; }
    public Long getVersion() { return version; }
    public UserAccount getOwner() { return owner; }

    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    public void setPixKey(String pixKey) { this.pixKey = pixKey; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }
    public void setStatus(AccountStatus status) { this.status = status; }
    public void setOwner(UserAccount owner) { this.owner = owner; }
}
