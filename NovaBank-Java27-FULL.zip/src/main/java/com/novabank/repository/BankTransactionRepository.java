package com.novabank.repository;

import com.novabank.entity.BankTransaction;
import com.novabank.entity.TransactionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public interface BankTransactionRepository extends JpaRepository<BankTransaction, UUID> {
    List<BankTransaction> findTop25ByAccount_IdOrderByCreatedAtDesc(UUID accountId);

    @Query("select coalesce(sum(t.amount), 0) from BankTransaction t where t.account.id = :accountId and t.type in :types")
    BigDecimal sumAmountByAccountAndTypes(@Param("accountId") UUID accountId,
                                          @Param("types") List<TransactionType> types);

    long countByAccount_Id(UUID accountId);

    void deleteAllByAccount_Id(UUID accountId);
}
