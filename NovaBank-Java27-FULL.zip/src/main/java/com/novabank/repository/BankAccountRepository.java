package com.novabank.repository;

import com.novabank.entity.BankAccount;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface BankAccountRepository extends JpaRepository<BankAccount, UUID> {
    Optional<BankAccount> findByOwner_Id(UUID ownerId);
    Optional<BankAccount> findByOwner_EmailIgnoreCase(String email);
    Optional<BankAccount> findByAccountNumber(String accountNumber);
    Optional<BankAccount> findByPixKeyIgnoreCase(String pixKey);
    boolean existsByAccountNumber(String accountNumber);
    boolean existsByPixKeyIgnoreCase(String pixKey);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select a from BankAccount a where a.id = :id")
    Optional<BankAccount> findByIdForUpdate(@Param("id") UUID id);
}
