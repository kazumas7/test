package com.novabank.service;

import com.novabank.entity.AccountStatus;
import com.novabank.entity.BankAccount;
import com.novabank.entity.BankTransaction;
import com.novabank.entity.TransactionType;
import com.novabank.entity.UserAccount;
import com.novabank.repository.BankAccountRepository;
import com.novabank.repository.BankTransactionRepository;
import com.novabank.repository.UserAccountRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.UUID;

@Component
public class DemoDataInitializer implements CommandLineRunner {
    private static final BigDecimal DEMO_BALANCE = new BigDecimal("1000000.00");

    private final UserAccountRepository users;
    private final BankAccountRepository accounts;
    private final BankTransactionRepository transactions;
    private final PasswordEncoder encoder;

    public DemoDataInitializer(UserAccountRepository users,
                               BankAccountRepository accounts,
                               BankTransactionRepository transactions,
                               PasswordEncoder encoder) {
        this.users = users;
        this.accounts = accounts;
        this.transactions = transactions;
        this.encoder = encoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        ensureDemoUser("Ana Silva", "ana@novabank.local", "12345678", "10000001", "ana@pix.novabank");
        ensureDemoUser("Bruno Lima", "bruno@novabank.local", "12345678", "10000002", "bruno@pix.novabank");
    }

    private void ensureDemoUser(String name, String email, String password, String accountNumber, String pixKey) {
        String normalizedEmail = email.toLowerCase(Locale.ROOT);
        UserAccount user = users.findByEmailIgnoreCase(normalizedEmail).orElseGet(UserAccount::new);
        user.setFullName(name);
        user.setEmail(normalizedEmail);
        user.setPasswordHash(encoder.encode(password));
        users.saveAndFlush(user);

        BankAccount account = accounts.findByOwner_Id(user.getId()).orElse(null);
        if (account == null) {
            account = new BankAccount();
            account.setOwner(user);
            account.setAccountNumber(accountNumber);
            account.setPixKey(pixKey);
            account.setBalance(DEMO_BALANCE);
            account.setStatus(AccountStatus.ACTIVE);
            user.setBankAccount(account);
            accounts.saveAndFlush(account);
            createInitialTransaction(account);
            return;
        }

        // Migração amigável de bancos criados pelas versões anteriores do projeto.
        if (account.getPixKey() == null || account.getPixKey().isBlank()) {
            account.setPixKey(pixKey);
        }
        if (account.getStatus() == null) {
            account.setStatus(AccountStatus.ACTIVE);
        }

        long txCount = transactions.countByAccount_Id(account.getId());
        if (txCount == 0) {
            account.setBalance(DEMO_BALANCE);
            accounts.saveAndFlush(account);
            createInitialTransaction(account);
        } else if (txCount == 1 && account.getBalance().compareTo(new BigDecimal("2500.00")) == 0) {
            // Converte a carteira da primeira versão (R$ 2.500) para o novo saldo pedido.
            account.setBalance(DEMO_BALANCE);
            accounts.saveAndFlush(account);
            transactions.findTop25ByAccount_IdOrderByCreatedAtDesc(account.getId()).stream().findFirst().ifPresent(tx -> {
                tx.setAmount(DEMO_BALANCE);
                tx.setDescription("Saldo inicial de demonstração");
                transactions.save(tx);
            });
        } else {
            accounts.save(account);
        }
    }

    private void createInitialTransaction(BankAccount account) {
        BankTransaction tx = new BankTransaction();
        tx.setAccount(account);
        tx.setType(TransactionType.DEPOSIT);
        tx.setAmount(DEMO_BALANCE);
        tx.setDescription("Saldo inicial de demonstração");
        tx.setCounterparty("Nova Bank");
        tx.setReferenceCode("DEMO-" + UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase(Locale.ROOT));
        transactions.save(tx);
    }
}
