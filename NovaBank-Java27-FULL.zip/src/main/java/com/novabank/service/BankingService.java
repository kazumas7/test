package com.novabank.service;

import com.novabank.dto.DashboardDto;
import com.novabank.dto.OperationResponse;
import com.novabank.entity.*;
import com.novabank.repository.BankAccountRepository;
import com.novabank.repository.BankTransactionRepository;
import com.novabank.repository.UserAccountRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Service
public class BankingService {
    private static final BigDecimal ZERO = new BigDecimal("0.00");
    private static final BigDecimal MAX_OPERATION = new BigDecimal("1000000.00");
    private static final DateTimeFormatter REF_TIME = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");

    private final UserAccountRepository users;
    private final BankAccountRepository accounts;
    private final BankTransactionRepository transactions;

    public BankingService(UserAccountRepository users,
                          BankAccountRepository accounts,
                          BankTransactionRepository transactions) {
        this.users = users;
        this.accounts = accounts;
        this.transactions = transactions;
    }

    @Transactional(readOnly = true)
    public DashboardDto dashboard(String email) {
        UserAccount user = getUser(email);
        BankAccount account = getAccountByOwner(user.getId());
        List<BankTransaction> rows = transactions.findTop25ByAccount_IdOrderByCreatedAtDesc(account.getId());
        BigDecimal incoming = transactions.sumAmountByAccountAndTypes(account.getId(),
                List.of(TransactionType.DEPOSIT, TransactionType.TRANSFER_IN, TransactionType.PIX_IN));
        BigDecimal outgoing = transactions.sumAmountByAccountAndTypes(account.getId(),
                List.of(TransactionType.WITHDRAWAL, TransactionType.TRANSFER_OUT, TransactionType.PIX_OUT));

        List<com.novabank.dto.TransactionDto> history = rows.stream()
                .map(tx -> new com.novabank.dto.TransactionDto(
                        tx.getType().name(),
                        isIncoming(tx.getType()),
                        tx.getDescription(),
                        tx.getAmount(),
                        tx.getCounterparty(),
                        tx.getReferenceCode(),
                        tx.getCreatedAt()))
                .toList();

        return new DashboardDto(
                user.getFullName(),
                user.getEmail(),
                account.getAccountNumber(),
                account.getPixKey(),
                account.getBalance(),
                incoming == null ? ZERO : incoming,
                outgoing == null ? ZERO : outgoing,
                history);
    }

    @Transactional
    public OperationResponse deposit(String email, BigDecimal rawAmount) {
        BigDecimal amount = normalizeAmount(rawAmount);
        BankAccount account = lockAccountByOwner(email);
        ensureActive(account);
        account.setBalance(account.getBalance().add(amount).setScale(2));
        BankTransaction tx = saveTransaction(account, TransactionType.DEPOSIT, amount,
                "Depósito em conta", "Caixa Nova Bank", reference("DEP"));
        return OperationResponse.success("Depósito realizado com sucesso.", tx.getReferenceCode(), account.getBalance());
    }

    @Transactional
    public OperationResponse withdraw(String email, BigDecimal rawAmount) {
        BigDecimal amount = normalizeAmount(rawAmount);
        BankAccount account = lockAccountByOwner(email);
        ensureActive(account);
        ensureEnoughBalance(account, amount);
        account.setBalance(account.getBalance().subtract(amount).setScale(2));
        BankTransaction tx = saveTransaction(account, TransactionType.WITHDRAWAL, amount,
                "Saque", "Caixa Nova Bank", reference("SAQ"));
        return OperationResponse.success("Saque realizado com sucesso.", tx.getReferenceCode(), account.getBalance());
    }

    @Transactional
    public OperationResponse transfer(String email, String targetAccountNumber, BigDecimal rawAmount) {
        BigDecimal amount = normalizeAmount(rawAmount);
        String targetNumber = targetAccountNumber == null ? "" : targetAccountNumber.trim();
        if (!targetNumber.matches("\\d{8}")) {
            throw new IllegalArgumentException("A conta de destino precisa ter 8 dígitos.");
        }

        BankAccount source = accounts.findByOwner_EmailIgnoreCase(email)
                .orElseThrow(() -> new IllegalArgumentException("Conta de origem não encontrada."));
        BankAccount target = accounts.findByAccountNumber(targetNumber)
                .orElseThrow(() -> new IllegalArgumentException("Conta de destino não encontrada."));

        if (source.getId().equals(target.getId())) {
            throw new IllegalArgumentException("A conta de destino precisa ser diferente da conta de origem.");
        }

        BankAccount[] locked = lockTwo(source.getId(), target.getId());
        BankAccount lockedSource = locked[0].getId().equals(source.getId()) ? locked[0] : locked[1];
        BankAccount lockedTarget = locked[0].getId().equals(target.getId()) ? locked[0] : locked[1];

        ensureActive(lockedSource);
        ensureActive(lockedTarget);
        ensureEnoughBalance(lockedSource, amount);

        lockedSource.setBalance(lockedSource.getBalance().subtract(amount).setScale(2));
        lockedTarget.setBalance(lockedTarget.getBalance().add(amount).setScale(2));
        String ref = reference("TRF");
        saveTransaction(lockedSource, TransactionType.TRANSFER_OUT, amount,
                "Transferência enviada", lockedTarget.getAccountNumber(), ref);
        saveTransaction(lockedTarget, TransactionType.TRANSFER_IN, amount,
                "Transferência recebida", lockedSource.getAccountNumber(), ref);

        return OperationResponse.success("Transferência realizada com sucesso.", ref, lockedSource.getBalance());
    }

    @Transactional
    public OperationResponse pix(String email, String rawPixKey, BigDecimal rawAmount) {
        BigDecimal amount = normalizeAmount(rawAmount);
        String pixKey = normalizePixKey(rawPixKey);
        if (pixKey.isBlank()) throw new IllegalArgumentException("Informe a chave Pix.");

        BankAccount source = accounts.findByOwner_EmailIgnoreCase(email)
                .orElseThrow(() -> new IllegalArgumentException("Conta de origem não encontrada."));
        BankAccount target = accounts.findByPixKeyIgnoreCase(pixKey)
                .orElseThrow(() -> new IllegalArgumentException("Chave Pix não encontrada."));

        if (source.getId().equals(target.getId())) {
            throw new IllegalArgumentException("A chave Pix de destino precisa ser diferente da sua.");
        }

        BankAccount[] locked = lockTwo(source.getId(), target.getId());
        BankAccount lockedSource = locked[0].getId().equals(source.getId()) ? locked[0] : locked[1];
        BankAccount lockedTarget = locked[0].getId().equals(target.getId()) ? locked[0] : locked[1];
        ensureActive(lockedSource);
        ensureActive(lockedTarget);
        ensureEnoughBalance(lockedSource, amount);

        lockedSource.setBalance(lockedSource.getBalance().subtract(amount).setScale(2));
        lockedTarget.setBalance(lockedTarget.getBalance().add(amount).setScale(2));
        String ref = reference("PIX");
        saveTransaction(lockedSource, TransactionType.PIX_OUT, amount,
                "Pix enviado", lockedTarget.getPixKey(), ref);
        saveTransaction(lockedTarget, TransactionType.PIX_IN, amount,
                "Pix recebido", lockedSource.getPixKey(), ref);

        return OperationResponse.success("Pix realizado com sucesso.", ref, lockedSource.getBalance());
    }

    @Transactional(readOnly = true)
    public String accountNameByNumber(String accountNumber) {
        return accounts.findByAccountNumber(accountNumber == null ? "" : accountNumber.trim())
                .map(a -> a.getOwner().getFullName())
                .orElseThrow(() -> new IllegalArgumentException("Conta não encontrada."));
    }

    @Transactional(readOnly = true)
    public String accountNameByPix(String pixKey) {
        return accounts.findByPixKeyIgnoreCase(normalizePixKey(pixKey))
                .map(a -> a.getOwner().getFullName())
                .orElseThrow(() -> new IllegalArgumentException("Chave Pix não encontrada."));
    }

    private BankAccount[] lockTwo(UUID one, UUID two) {
        List<UUID> ids = List.of(one, two).stream().sorted(Comparator.comparing(UUID::toString)).toList();
        BankAccount first = accounts.findByIdForUpdate(ids.get(0))
                .orElseThrow(() -> new IllegalArgumentException("Conta envolvida não encontrada."));
        BankAccount second = accounts.findByIdForUpdate(ids.get(1))
                .orElseThrow(() -> new IllegalArgumentException("Conta envolvida não encontrada."));
        return new BankAccount[]{first, second};
    }

    private BankTransaction saveTransaction(BankAccount account,
                                            TransactionType type,
                                            BigDecimal amount,
                                            String description,
                                            String counterparty,
                                            String reference) {
        BankTransaction tx = new BankTransaction();
        tx.setAccount(account);
        tx.setType(type);
        tx.setAmount(amount);
        tx.setDescription(description);
        tx.setCounterparty(counterparty);
        tx.setReferenceCode(reference);
        return transactions.save(tx);
    }

    private UserAccount getUser(String email) {
        return users.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado."));
    }

    private BankAccount getAccountByOwner(UUID ownerId) {
        return accounts.findByOwner_Id(ownerId)
                .orElseThrow(() -> new IllegalArgumentException("Conta bancária não encontrada."));
    }

    private BankAccount lockAccountByOwner(String email) {
        BankAccount account = accounts.findByOwner_EmailIgnoreCase(email)
                .orElseThrow(() -> new IllegalArgumentException("Conta bancária não encontrada."));
        return accounts.findByIdForUpdate(account.getId())
                .orElseThrow(() -> new IllegalArgumentException("Conta bancária não encontrada."));
    }

    private void ensureActive(BankAccount account) {
        if (account.getStatus() != AccountStatus.ACTIVE) {
            throw new IllegalArgumentException("A conta está bloqueada.");
        }
    }

    private void ensureEnoughBalance(BankAccount account, BigDecimal amount) {
        if (account.getBalance().compareTo(amount) < 0) {
            throw new IllegalArgumentException("Saldo insuficiente.");
        }
    }

    private BigDecimal normalizeAmount(BigDecimal rawAmount) {
        if (rawAmount == null) throw new IllegalArgumentException("Informe um valor.");
        BigDecimal amount = rawAmount.setScale(2, RoundingMode.HALF_UP);
        if (amount.compareTo(BigDecimal.ZERO) <= 0) throw new IllegalArgumentException("O valor deve ser maior que zero.");
        if (amount.compareTo(MAX_OPERATION) > 0) throw new IllegalArgumentException("Limite por operação: R$ 1.000.000,00.");
        return amount;
    }

    private String normalizePixKey(String key) {
        return key == null ? "" : key.trim().toLowerCase(Locale.ROOT);
    }

    private boolean isIncoming(TransactionType type) {
        return type == TransactionType.DEPOSIT || type == TransactionType.TRANSFER_IN || type == TransactionType.PIX_IN;
    }

    private String reference(String prefix) {
        return String.format(Locale.ROOT, "%s-%s-%s", prefix,
                LocalDateTime.now().format(REF_TIME),
                UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.ROOT));
    }
}
