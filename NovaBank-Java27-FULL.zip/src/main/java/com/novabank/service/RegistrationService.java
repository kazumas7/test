package com.novabank.service;

import com.novabank.entity.BankAccount;
import com.novabank.entity.UserAccount;
import com.novabank.repository.BankAccountRepository;
import com.novabank.repository.UserAccountRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.UUID;

@Service
public class RegistrationService {
    private final UserAccountRepository users;
    private final BankAccountRepository accounts;
    private final PasswordEncoder passwordEncoder;
    private final SecureRandom random = new SecureRandom();

    public RegistrationService(UserAccountRepository users,
                               BankAccountRepository accounts,
                               PasswordEncoder passwordEncoder) {
        this.users = users;
        this.accounts = accounts;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public void register(String fullName, String email, String password) {
        String name = fullName == null ? "" : fullName.trim();
        String normalizedEmail = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        validate(name, normalizedEmail, password);
        if (users.existsByEmailIgnoreCase(normalizedEmail)) {
            throw new IllegalArgumentException("Já existe uma conta com este e-mail.");
        }

        UserAccount user = new UserAccount();
        user.setFullName(name);
        user.setEmail(normalizedEmail);
        user.setPasswordHash(passwordEncoder.encode(password));
        users.saveAndFlush(user);

        BankAccount account = new BankAccount();
        account.setOwner(user);
        user.setBankAccount(account);
        account.setAccountNumber(generateUniqueAccountNumber());
        account.setPixKey(generateUniquePixKey());
        account.setBalance(BigDecimal.ZERO.setScale(2));
        account.setStatus(com.novabank.entity.AccountStatus.ACTIVE);
        try {
            accounts.save(account);
        } catch (DataIntegrityViolationException ex) {
            throw new IllegalArgumentException("Não foi possível criar a conta. Tente novamente.");
        }
    }

    private void validate(String name, String email, String password) {
        if (name.length() < 2) throw new IllegalArgumentException("Informe seu nome completo.");
        if (name.length() > 100) throw new IllegalArgumentException("O nome é muito longo.");
        if (!email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) throw new IllegalArgumentException("Informe um e-mail válido.");
        if (password == null || password.length() < 8) throw new IllegalArgumentException("A senha precisa ter pelo menos 8 caracteres.");
    }

    private String generateUniqueAccountNumber() {
        for (int attempt = 0; attempt < 100; attempt++) {
            String number = String.format(Locale.ROOT, "%08d", 10_000_000 + random.nextInt(90_000_000));
            if (!accounts.existsByAccountNumber(number)) return number;
        }
        throw new IllegalStateException("Não foi possível gerar o número da conta.");
    }

    private String generateUniquePixKey() {
        for (int attempt = 0; attempt < 100; attempt++) {
            String key = "pix-" + UUID.randomUUID().toString().replace("-", "").substring(0, 20);
            if (!accounts.existsByPixKeyIgnoreCase(key)) return key;
        }
        throw new IllegalStateException("Não foi possível gerar a chave Pix.");
    }
}
