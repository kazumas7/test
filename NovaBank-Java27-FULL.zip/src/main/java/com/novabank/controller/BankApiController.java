package com.novabank.controller;

import com.novabank.dto.*;
import com.novabank.service.BankingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@RequestMapping("/api")
public class BankApiController {
    private final BankingService bankingService;

    public BankApiController(BankingService bankingService) {
        this.bankingService = bankingService;
    }

    @GetMapping("/dashboard")
    public DashboardDto dashboard(Principal principal) {
        return bankingService.dashboard(principal.getName());
    }

    @PostMapping("/deposit")
    public OperationResponse deposit(@RequestBody MoneyRequest request, Principal principal) {
        return bankingService.deposit(principal.getName(), request.amount());
    }

    @PostMapping("/withdraw")
    public OperationResponse withdraw(@RequestBody MoneyRequest request, Principal principal) {
        return bankingService.withdraw(principal.getName(), request.amount());
    }

    @PostMapping("/transfer")
    public OperationResponse transfer(@RequestBody TransferRequest request, Principal principal) {
        return bankingService.transfer(principal.getName(), request.targetAccount(), request.amount());
    }

    @PostMapping("/pix")
    public OperationResponse pix(@RequestBody PixRequest request, Principal principal) {
        return bankingService.pix(principal.getName(), request.pixKey(), request.amount());
    }

    @GetMapping("/lookup/account/{accountNumber}")
    public ResponseEntity<?> lookupAccount(@PathVariable String accountNumber) {
        try {
            return ResponseEntity.ok(new LookupResponse(true, bankingService.accountNameByNumber(accountNumber), null));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(new LookupResponse(false, null, ex.getMessage()));
        }
    }

    @GetMapping("/lookup/pix")
    public ResponseEntity<?> lookupPix(@RequestParam String key) {
        try {
            return ResponseEntity.ok(new LookupResponse(true, bankingService.accountNameByPix(key), null));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(new LookupResponse(false, null, ex.getMessage()));
        }
    }

    public record LookupResponse(boolean found, String ownerName, String message) {}
}
