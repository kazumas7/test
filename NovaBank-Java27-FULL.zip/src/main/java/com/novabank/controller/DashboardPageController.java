package com.novabank.controller;

import com.novabank.dto.DashboardDto;
import com.novabank.dto.OperationResponse;
import com.novabank.service.BankingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.Principal;

@Controller
public class DashboardPageController {
    private final BankingService bankingService;

    public DashboardPageController(BankingService bankingService) {
        this.bankingService = bankingService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Principal principal, Model model) {
        DashboardDto dashboard = bankingService.dashboard(principal.getName());
        model.addAttribute("dashboard", dashboard);
        return "dashboard";
    }
}
