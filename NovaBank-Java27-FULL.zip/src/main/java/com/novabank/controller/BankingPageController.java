package com.novabank.controller;

import com.novabank.service.BankingService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.security.Principal;

@Controller
public class BankingPageController {
    private final BankingService bankingService;

    public BankingPageController(BankingService bankingService) {
        this.bankingService = bankingService;
    }

    @PostMapping("/deposit")
    public String deposit(@RequestParam BigDecimal amount, Principal principal, RedirectAttributes redirect) {
        return run(() -> bankingService.deposit(principal.getName(), amount), redirect);
    }

    @PostMapping("/withdraw")
    public String withdraw(@RequestParam BigDecimal amount, Principal principal, RedirectAttributes redirect) {
        return run(() -> bankingService.withdraw(principal.getName(), amount), redirect);
    }

    @PostMapping("/transfer")
    public String transfer(@RequestParam String targetAccount,
                           @RequestParam BigDecimal amount,
                           Principal principal,
                           RedirectAttributes redirect) {
        return run(() -> bankingService.transfer(principal.getName(), targetAccount, amount), redirect);
    }

    @PostMapping("/pix")
    public String pix(@RequestParam String pixKey,
                      @RequestParam BigDecimal amount,
                      Principal principal,
                      RedirectAttributes redirect) {
        return run(() -> bankingService.pix(principal.getName(), pixKey, amount), redirect);
    }

    private String run(java.util.function.Supplier<com.novabank.dto.OperationResponse> operation,
                       RedirectAttributes redirect) {
        try {
            var result = operation.get();
            redirect.addFlashAttribute("success", result.message() + " Ref.: " + result.reference());
        } catch (IllegalArgumentException ex) {
            redirect.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/dashboard";
    }
}
