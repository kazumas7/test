package com.novabank.dto;

import java.math.BigDecimal;

public record PixRequest(String pixKey, BigDecimal amount) {}
