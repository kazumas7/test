package com.novabank.dto;

import java.math.BigDecimal;

public record TransferRequest(String targetAccount, BigDecimal amount) {}
