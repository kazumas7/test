package com.novabank.dto;

import java.math.BigDecimal;

public record OperationResponse(
        boolean success,
        String message,
        String reference,
        BigDecimal newBalance
) {
    public static OperationResponse success(String message, String reference, BigDecimal balance) {
        return new OperationResponse(true, message, reference, balance);
    }

    public static OperationResponse failure(String message) {
        return new OperationResponse(false, message, null, null);
    }
}
