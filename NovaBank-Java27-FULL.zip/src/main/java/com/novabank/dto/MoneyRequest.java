package com.novabank.dto;

import java.math.BigDecimal;

public record MoneyRequest(BigDecimal amount) {}
