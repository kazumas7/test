package com.novabank.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record TransactionDto(
        String type,
        boolean incoming,
        String description,
        BigDecimal amount,
        String counterparty,
        String referenceCode,
        LocalDateTime createdAt
) {}
