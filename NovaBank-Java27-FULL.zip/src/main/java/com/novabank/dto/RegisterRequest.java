package com.novabank.dto;

public record RegisterRequest(String fullName, String email, String password) {}
