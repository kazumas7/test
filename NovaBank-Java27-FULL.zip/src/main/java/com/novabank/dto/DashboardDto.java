package com.novabank.dto;

import java.math.BigDecimal;
import java.util.List;

public record DashboardDto(
        String name,
        String email,
        String accountNumber,
        String pixKey,
        BigDecimal balance,
        BigDecimal totalIncoming,
        BigDecimal totalOutgoing,
        List<TransactionDto> transactions
) {}
