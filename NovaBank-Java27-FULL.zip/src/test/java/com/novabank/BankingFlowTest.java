package com.novabank;

import com.novabank.repository.BankAccountRepository;
import com.novabank.service.BankingService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
@ActiveProfiles("test")
class BankingFlowTest {
    @Autowired BankingService bankingService;
    @Autowired BankAccountRepository accounts;

    @Test
    @Transactional
    void transferMovesMoneyBetweenAccountsAndPixAlsoMovesMoney() {
        var anaBefore = accounts.findByAccountNumber("10000001").orElseThrow().getBalance();
        var brunoBefore = accounts.findByAccountNumber("10000002").orElseThrow().getBalance();

        bankingService.transfer("ana@novabank.local", "10000002", new BigDecimal("100.00"));
        bankingService.pix("bruno@novabank.local", "ana@pix.novabank", new BigDecimal("25.00"));

        var anaAfter = accounts.findByAccountNumber("10000001").orElseThrow().getBalance();
        var brunoAfter = accounts.findByAccountNumber("10000002").orElseThrow().getBalance();

        assertEquals(anaBefore.subtract(new BigDecimal("75.00")), anaAfter);
        assertEquals(brunoBefore.add(new BigDecimal("75.00")), brunoAfter);
    }

    @Test
    void depositAndWithdrawalKeepExactDecimalMoney() {
        var before = accounts.findByAccountNumber("10000001").orElseThrow().getBalance();
        bankingService.deposit("ana@novabank.local", new BigDecimal("12.34"));
        bankingService.withdraw("ana@novabank.local", new BigDecimal("2.34"));
        var after = accounts.findByAccountNumber("10000001").orElseThrow().getBalance();
        assertEquals(before.add(new BigDecimal("10.00")), after);
    }
}
