package com.novabank;

import com.novabank.repository.UserAccountRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class AuthenticationTest {
    @Autowired MockMvc mvc;
    @Autowired UserAccountRepository users;
    @Autowired PasswordEncoder encoder;

    @Test
    void demoPasswordsAreValid() {
        var ana = users.findByEmailIgnoreCase("ana@novabank.local").orElseThrow();
        var bruno = users.findByEmailIgnoreCase("bruno@novabank.local").orElseThrow();
        assertTrue(encoder.matches("12345678", ana.getPasswordHash()));
        assertTrue(encoder.matches("12345678", bruno.getPasswordHash()));
    }

    @Test
    void loginWorks() throws Exception {
        mvc.perform(post("/login")
                        .with(csrf())
                        .param("username", "ana@novabank.local")
                        .param("password", "12345678"))
                .andExpect(redirectedUrl("/dashboard"));
    }
}
